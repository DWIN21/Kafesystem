<?php
session_start();


if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}

// Database connection
include('../conn/connection.php');
// Handle add to cart
if (isset($_POST['add_to_cart'])) {
    $item_id = $_POST['item_id'];
    $quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 1;

    if (isset($_SESSION['cart'][$item_id])) {
        $_SESSION['cart'][$item_id] += $quantity;
    } else {
        $_SESSION['cart'][$item_id] = $quantity;
    }

    echo "<script>alert('Item added to cart!');</script>";
}

// Handle clear cart
if (isset($_POST['clear_cart'])) {
    $_SESSION['cart'] = array(); // Empty the cart
    echo "<script>alert('Cart has been cleared!');</script>";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu</title>
    <link rel="shortcut icon" type="x-icon" href="Ka'fe logo.png">
    <link rel="stylesheet" href="css/login_tset.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #000;
            color: #f8f4f0;
            margin: 0;
            padding: 0;
        }

        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            background-color: #333;
            color: #fff;
        }

        h1.logo {
            font-size: 2.5em;
            margin: 0;
            font-family: 'Georgia', serif;
            color: #f8f4f0;
            text-align: left;
        }

        .back-button {
            background-color: #444;
            color: #f8f4f0;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .back-button:hover {
            background-color: #666;
        }

        form {
            margin: 20px 0;
        }

        select {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #555;
            border-radius: 5px;
            background-color: #333;
            color: #f8f4f0;
        }

        table {
            width: 90%;
            margin: 20px auto;
            border-collapse: collapse;
            background-color: #111;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
            border-radius: 10px;
            overflow: hidden;
        }

        th, td {
            padding: 15px;
            text-align: center;
            border-bottom: 1px solid #555;
        }

        th {
            background-color: #444;
            color: #f8f4f0;
            font-weight: bold;
        }

        td {
            background-color: #222;
            color: #f8f4f0;
        }

        .menu-image {
            width: 120px;
            height: auto;
            border-radius: 10px;
            box-shadow: 0 0 5px rgba(255, 255, 255, 0.1);
        }

        .add-to-cart, .proceed-checkout, .clear-cart {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        .add-to-cart {
            background-color: #f8f4f0;
            color: #333;
        }

        .add-to-cart:hover {
            background-color: #333;
            color: #f8f4f0;
        }

        .proceed-checkout {
            background-color: #ffcc00;
            color: #333;
            font-size: 18px;
        }

        .clear-cart {
            background-color: #ff4d4d;
            color: #fff;
            font-size: 16px;
        }

        .clear-cart:hover {
            background-color: #cc0000;
        }

        input[type="number"] {
            width: 60px;
            padding: 8px;
            font-size: 16px;
            border: 1px solid #555;
            border-radius: 5px;
            background-color: #333;
            color: #f8f4f0;
            text-align: center;
            transition: border 0.3s ease;
        }

        input[type="number"]:hover {
            border: 1px solid #f8f4f0;
        }

        footer {
            text-align: center;
            padding: 20px;
            background-color: #333;
            color: #f8f4f0;
            margin-top: 40px;
        }

        footer p {
            margin: 5px 0;
        }

        /* Media Queries for Responsiveness */
        @media screen and (max-width: 768px) {
            body {
                font-size: 16px;
            }

            table {
                width: 100%;
            }

            .menu-image {
                width: 80px;
            }

            th, td {
                padding: 10px;
            }

            .add-to-cart, .proceed-checkout, .clear-cart {
                padding: 8px 16px;
                font-size: 14px;
            }

            .proceed-checkout {
                font-size: 16px;
            }

            input[type="number"] {
                width: 50px;
            }
        }

        @media screen and (max-width: 480px) {
            h1.logo {
                font-size: 1.8em;
            }

            .menu-image {
                width: 60px;
            }

            th, td {
                padding: 8px;
                font-size: 14px;
            }

            .add-to-cart, .proceed-checkout, .clear-cart {
                padding: 6px 12px;
                font-size: 12px;
            }

            .proceed-checkout {
                font-size: 14px;
            }

            input[type="number"] {
                width: 40px;
                font-size: 14px;
            }
        }

    </style>
</head>

<body>
    <header>
        <h1 class="logo">KA'fe Menu</h1>
        <button class="back-button" onclick="history.back()">Back</button>
    </header>

    <form method="post" action="">
        <label for="category">Select Category:</label>
        <select name="category" id="category" onchange="this.form.submit()">
            <option value="">All Categories</option>
            <?php
            $sql_categories = "SELECT DISTINCT Category FROM menuitem";
            $result_categories = $conn->query($sql_categories);

            if ($result_categories->num_rows > 0) {
                while ($row = $result_categories->fetch_assoc()) {
                    $selected = isset($_POST['category']) && $_POST['category'] == $row['Category'] ? 'selected' : '';
                    echo "<option value='" . $row['Category'] . "' $selected>" . $row['Category'] . "</option>";
                }
            } else {
                echo "<option value=''>No categories available</option>";
            }
            ?>
        </select>
    </form>

    <table>
        <thead>
            <tr>
                <th>Image</th>
                <th>Item Name</th>
                <th>Price</th>
                <th>Description</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $selected_category = isset($_POST['category']) ? $_POST['category'] : '';

            $sql = "SELECT * FROM menuitem";
            if ($selected_category) {
                $sql .= " WHERE Category='$selected_category'";
            }

            $result = $conn->query($sql);

            if (!$result) {
                die("Error executing query: " . $conn->error);
            }

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td><img src='../Admin/uploads/" . $row['ImageName'] . "' alt='" . $row['ItemName'] . "' class='menu-image'></td>";
                    echo "<td>" . $row['ItemName'] . "</td>";
                    echo "<td>" . $row['Price'] . "</td>";
                    echo "<td>" . $row['description'] . "</td>";
                    echo "<td>
                        <form method='post' action=''>
                            <input type='hidden' name='item_id' value='" . $row['MenuItemID'] . "'>
                            <input type='number' name='quantity' value='1' min='1' style='width: 60px;'>
                            <input type='submit' name='add_to_cart' value='Add to Cart' class='add-to-cart'>
                        </form>
                    </td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='5'>No items found</td></tr>";
            }

            $conn->close();
            ?>
        </tbody>
    </table>

    <div style="text-align:center; margin-top: 20px;">
        <form action="checkout.php" method="post">
            <input type="submit" value="Proceed to Checkout" class="proceed-checkout">
        </form>
        <form method="post" action="" style="margin-top: 10px;">
            <input type="submit" name="clear_cart" value="Clear Order" class="clear-cart">
        </form>
    </div>

    <footer>
        <p>San Jose, Blanga, Bataan.</p>
        <p><u>0956 490 2330</u></p>
        <p><u>kafecoffeehouse@gmail.com</u></p>
        <p>&copy; 2024 Ka'fe. All rights reserved.</p>
    </footer>
</body>

</html>

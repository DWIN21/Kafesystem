<?php
session_start();

if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    echo "<script>alert('Your cart is empty. Please add items to proceed to payment.'); window.location.href='menu.php';</script>";
    exit();
}

// Database connection
include('../conn/connection.php');

// Retrieve items from the cart
$cart_items = $_SESSION['cart'];
$total_price = 0;
$discount_percentage = 0; // Initialize discount percentage

// Process payment (after submission)
if (isset($_POST['process_payment'])) {
    // Handle discount
    $discount_type = $_POST['discount_type'];
    if ($discount_type == "student" || $discount_type == "senior") {
        $discount_percentage = 20; // Apply 20% discount for students or senior citizens

        // Check if proof of discount is uploaded
        if (isset($_FILES['discount_proof']) && $_FILES['discount_proof']['error'] == 0) {
            $file_name = $_FILES['discount_proof']['name'];
            $file_tmp = $_FILES['discount_proof']['tmp_name'];
            $upload_dir = 'uploads/discount_proofs/';

            // Ensure the uploads directory exists
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }

            // Save the uploaded file
            move_uploaded_file($file_tmp, $upload_dir . $file_name);
        } else {
            echo "<script>alert('Please upload proof of discount for Student or Senior discount.');</script>";
            exit();
        }
    }

    // Calculate the total price of all items in the cart
    foreach ($cart_items as $item_id => $quantity) {
        $sql = "SELECT Price FROM menuitem WHERE MenuItemID='$item_id'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $price = $row['Price'];
            $total_price += $price * $quantity; // Calculate the total price of the cart
        }
    }

    // Now apply the discount percentage
    $discount_amount = ($total_price * $discount_percentage) / 100;
    $discounted_price = $total_price - $discount_amount;

    // Handle GCash payment proof
    $payment_method = $_POST['payment_method'];
    if ($payment_method == "gcash") {
        // Check if proof of payment is uploaded
        if (isset($_FILES['gcash_proof']) && $_FILES['gcash_proof']['error'] == 0) {
            $file_name = $_FILES['gcash_proof']['name'];
            $file_tmp = $_FILES['gcash_proof']['tmp_name'];
            $upload_dir = 'uploads/gcash_proofs/';

            // Ensure the uploads directory exists
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }

            // Save the uploaded file
            move_uploaded_file($file_tmp, $upload_dir . $file_name);
        } else {
            echo "<script>alert('Please upload proof of payment for GCash.');</script>";
            exit();
        }
    }

    // Simulate processing payment and clearing cart
    $_SESSION['cart'] = array(); // Clear the cart
    echo "<script>alert('Payment successful! Discount Applied: ₱" . number_format($discount_amount, 2) . ". Total paid: ₱" . number_format($discounted_price, 2) . "'); window.location.href='menu.php';</script>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment</title>
    <link rel="stylesheet" href="css/login_tset.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #000;
            color: #f8f4f0;
            margin: 0;
            padding: 0;
        }

        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            background-color: #333;
            color: #fff;
        }

        h1.logo {
            font-size: 2.5em;
            margin: 0;
            font-family: 'Georgia', serif;
            color: #f8f4f0;
        }

        .back-button {
            background-color: #444;
            color: #f8f4f0;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .back-button:hover {
            background-color: #666;
        }

        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
            background-color: #111;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
            border-radius: 10px;
        }

        th, td {
            padding: 15px;
            text-align: center;
            border-bottom: 1px solid #555;
        }

        th {
            background-color: #444;
            color: #f8f4f0;
        }

        td {
            background-color: #222;
            color: #f8f4f0;
        }

        .menu-image {
            width: 100px;
            height: auto;
            border-radius: 5px;
        }

        .total {
            font-size: 20px;
            font-weight: bold;
            color: #ffcc00;
        }

        .payment-form {
            width: 50%;
            margin: 20px auto;
            padding: 20px;
            background-color: #222;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
        }

        .payment-form select, .payment-form input[type="submit"] {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            margin-top: 10px;
            border-radius: 5px;
            border: 1px solid #555;
            background-color: #333;
            color: #f8f4f0;
            transition: background-color 0.3s ease;
        }

        .payment-form input[type="submit"]:hover {
            background-color: #444;
        }

        .discount-option {
            margin-top: 10px;
            padding: 10px;
            background-color: #333;
            border-radius: 5px;
        }

        .file-upload {
            margin-top: 10px;
            padding: 10px;
            background-color: #444;
            border-radius: 5px;
        }

        .discount-proof {
            display: none;
            margin-top: 10px;
        }

        .gcash-proof {
            display: none;
            margin-top: 10px;
        }

        footer {
            text-align: center;
            padding: 20px;
            background-color: #333;
            color: #f8f4f0;
            margin-top: 40px;
        }

        footer p {
            margin: 5px 0;
        }
    </style>

    <script>
        function showGcashProof() {
            const paymentMethod = document.querySelector('select[name="payment_method"]').value;
            const gcashProof = document.querySelector('.gcash-proof');
            if (paymentMethod === 'gcash') {
                gcashProof.style.display = 'block';
            } else {
                gcashProof.style.display = 'none';
            }
        }

        function showDiscountProof() {
            const discountType = document.querySelector('select[name="discount_type"]').value;
            const discountProof = document.querySelector('.discount-proof');
            if (discountType === 'student' || discountType === 'senior') {
                discountProof.style.display = 'block';
            } else {
                discountProof.style.display = 'none';
            }
        }
    </script>
</head>

<body>
    <header>
        <h1 class="logo">KA'fe Payment</h1>
        <button class="back-button" onclick="history.back()">Go Back</button>
    </header>

    <table>
        <thead>
            <tr>
                <th>Item Name</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php
            foreach ($cart_items as $item_id => $quantity) {
                $sql = "SELECT * FROM menuitem WHERE MenuItemID='$item_id'";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $item_name = $row['ItemName'];
                        $price = $row['Price'];
                        $item_total = $price * $quantity;
                        $total_price += $item_total;
                        echo "<tr>
                                <td>" . $item_name . "</td>
                                <td>" . $quantity . "</td>
                                <td>₱" . number_format($price, 2) . "</td>
                                <td>₱" . number_format($item_total, 2) . "</td>
                            </tr>";
                    }
                }
            }
            ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="3" class="total">Total Price</td>
                <td class="total">₱<?php echo number_format($total_price, 2); ?></td>
            </tr>
        </tfoot>
    </table>

    <form class="payment-form" method="post" enctype="multipart/form-data">
        <select name="payment_method" onchange="showGcashProof()">
            <option value="cash">Cash</option>
            <option value="gcash">GCash</option>
        </select>

        <div class="gcash-proof">
            <label for="gcash_proof">Upload GCash Proof of Payment:</label>
            <input type="file" name="gcash_proof" class="file-upload" accept="image/*">
        </div>

        <div class="discount-option">
            <label for="discount_type">Discount:</label>
            <select name="discount_type" onchange="showDiscountProof()">
                <option value="none">None</option>
                <option value="student">Student</option>
                <option value="senior">Senior Citizen</option>
            </select>

            <div class="discount-proof">
                <label for="discount_proof">Upload Proof of Discount (ID):</label>
                <input type="file" name="discount_proof" class="file-upload" accept="image/*">
            </div>
        </div>

        <input type="submit" name="process_payment" value="Process Payment">
    </form>

    <footer>
        <p>&copy; 2024 KA'fe Coffee Shop. All rights reserved.</p>
    </footer>
</body>

</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu Management</title>
    <link rel="shortcut icon" type="image/x-icon" href="Ka'fe logo.png">
    <style>
        body {
            font-family: 'Georgia', serif;
            margin: 0;
            padding: 0;
            background: url('../ background.png') no-repeat center center fixed;
            background-size: cover;
            color: #4b3832;
        }
s
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #00bcd4;
            color: #fff;
            padding: 10px 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .logo {
            font-size: 36px;
            font-weight: bold;
            color: #fff;
            font-family: 'Times New Roman', cursive;
            color: rgb(81, 60, 32);
        }

        .navigation a {
            color: #fff;
            text-decoration: none;
            margin: 0 15px;
            font-size: 16px;
            transition: color 0.3s;
        }

        .navigation a:hover {
            color: #ffeb3b;
        }

        main {
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }

        .form-container {
            background: rgba(255, 255, 255, 0.9);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 600px;
            box-sizing: border-box;
            margin: 20px;
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .form-container label {
            display: block;
            margin: 0 0 5px;
            font-weight: bold;
        }

        .form-container select,
        .form-container input {
            padding: 12px;
            border: 1px solid #d9b38c;
            border-radius: 5px;
            font-size: 16px;
            width: 100%;
            box-sizing: border-box;
        }

        /* General button styles */
        .form-container button {
            padding: 12px;
            background-color: #8e6e53;
            color: #fff;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            font-size: 16px;
            transition: background-color 0.3s;
            width: 100%;
            box-sizing: border-box;
        }

        /* Add Ingredient button styles */
        #add-ingredient-btn {
            padding: 8px;
            margin-bottom: 5px;
            font-size: 14px;
            width: auto; /* To ensure it doesn't stretch the full width */
            align-self: flex-start; /* Align "Add Ingredient" button to the start */
        }

        /* Add Menu Item button styles */
        .form-container button[type="submit"] {
            padding: 16px;
            font-size: 18px;
        }

        .ingredient-section {
            margin-top: 20px;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .ingredient-input {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 10px;
        }

        .ingredient-input label {
            flex: 1;
        }

        .ingredient-input input {
            flex: 2;
        }

        .inventory-section {
            width: 100%;
            max-width: 800px;
            background: rgba(255, 255, 255, 0.9);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            margin: 20px 0;
        }

        .inventory-section h2 {
            background-color: #d9b38c;
            padding: 10px;
            border-radius: 5px;
            color: #4b3832;
            text-align: center;
            margin-bottom: 20px;
        }

        .inventory-section ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }

        .inventory-section li {
            background-color: #f5f0e1;
            margin: 10px 0;
            padding: 10px 20px;
            border-radius: 5px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: transform 0.3s;
        }

        .inventory-section li:hover {
            transform: scale(1.02);
        }

        .inventory-section li button {
            background-color: #8e6e53;
            color: #f5f0e1;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            padding: 5px 10px;
            margin-left: 10px;
            transition: background-color 0.3s;
        }

        .inventory-section li button:hover {
            background-color: #7a5b46;
        }

        footer {
            background-color: rgba(255, 255, 255, 0.8);
            text-align: center;
            padding: 10px 0;
            position: fixed;
            width: 100%;
            bottom: 0;
            box-shadow: 0 -4px 6px rgba(0, 0, 0, 0.1);
        }

        footer p {
            margin: 0;
            color: rgb(81, 60, 32);
        }

        @media (max-width: 768px) {
            .logo {
                font-size: 28px;
            }

            .navigation a {
                font-size: 14px;
            }

            .form-container {
                padding: 15px;
                gap: 10px;
            }

            .form-container button {
                font-size: 14px;
                padding: 10px;
            }
        }
    </style>
</head>
<body>
    <header>
        <h1 class="logo">MENU MANAGEMENT</h1>
        <nav class="navigation">
            <a href="Admin_Dashboard.php">Admin Dashboard</a>
            <a href="Menu_test.php">Menu</a>
            <a href="Inventory_test.html">Inventory</a>
            <a href="POS_test.php">POS</a>
            <a href="Report_test.html">Report</a>
            <a href="Add_user.php">Add User</a>
        </nav>
    </header>
    <main>
        <div class="form-container">
            <h2>Add Menu Item</h2>
            <form action="Menu_test.php" method="POST">
            <label for="category">Category</label>
            <select id="category" name="category" required>
                <option value="drinks">Drinks</option>
                <option value="pastries">Pastries</option>
            </select>
            <label for="menu-name">Menu Name</label>
            <input type="text" id="menu-name" name="menu-name" placeholder="Menu Name" required>
            <label for="product-price">Product Price</label>
            <input type="number" id="product-price" name="product-price" placeholder="Product Price" required>

            <div class="ingredient-section">
                <h3>Ingredients</h3>
                <div id="ingredients-container">
                    <!-- Ingredient inputs will be added here -->
                </div>
                <button id="add-ingredient-btn">Add Ingredient</button>
            </div>

            <button type="submit">Add Menu Item</button>
        </form>
        </div>
        <div class="inventory-section">
            <h2>Menu Items</h2>
          <!--  <ul>
                <li>Drink - Example Drink 1 - Price: $2.00 <button>-</button></li>
                <li>Dessert - Example Dessert 1 - Price: $5.00 <button>-</button></li>
                <li>Drink - Example Drink 2 - Price: $3.50 <button>-</button></li>
            </ul> -->
        </div>
    </main>
    <footer>
        <p>&copy; 2024 Ka'fe. All rights reserved.</p>
    </footer>
    <script>
        let ingredientCount = 0;
        const maxIngredients = 10;

        document.getElementById('add-ingredient-btn').addEventListener('click', function(event) {
            event.preventDefault();
            if (ingredientCount < maxIngredients) {
                ingredientCount++;
                const ingredientsContainer = document.getElementById('ingredients-container');
                const ingredientDiv = document.createElement('div');
                ingredientDiv.classList.add('ingredient-input');
                ingredientDiv.innerHTML = `
                    <label for="ingredient-${ingredientCount}">Ingredient ${ingredientCount}</label>
                    <input type="text" id="ingredient-${ingredientCount}" name="ingredient-${ingredientCount}" placeholder="Ingredient Name" required>
                    <label for="quantity-${ingredientCount}">Quantity</label>
                    <input type="text" id="quantity-${ingredientCount}" name="quantity-${ingredientCount}" placeholder="Quantity" required>
                `;
                ingredientsContainer.appendChild(ingredientDiv);
            }
        });
    </script>
</body>
</html>

<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kafesystem";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $itemName = $_POST['menu-name'];
    $price = $_POST['product-price'];
    $category = $_POST['category'];

    // Insert menu item
    $sql = "INSERT INTO MenuItem (ItemName, Price, Category) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sds", $itemName, $price, $category);
    $stmt->execute();
    $menuItemID = $stmt->insert_id; // Get the last inserted ID

    // Insert ingredients
    for ($i = 1; $i <= 10; $i++) {
        if (isset($_POST["ingredient-$i"]) && isset($_POST["quantity-$i"])) {
            $ingredientName = $_POST["ingredient-$i"];
            $quantity = $_POST["quantity-$i"];

            // Check if ingredient already exists
            $sql = "SELECT IngredientID FROM Ingredient WHERE IngredientName = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $ingredientName);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $ingredientID = $result->fetch_assoc()['IngredientID'];
            } else {
                // Insert new ingredient
                $sql = "INSERT INTO Ingredient (IngredientName) VALUES (?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("s", $ingredientName);
                $stmt->execute();
                $ingredientID = $stmt->insert_id;
            }

            // Insert into MenuItemIngredient
            $sql = "INSERT INTO MenuItemIngredient (MenuItemID, IngredientID, Quantity) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("iis", $menuItemID, $ingredientID, $quantity);
            $stmt->execute();
        }
    }

    echo "<script>alert('Menu item added successfully!'); window.location.href='Menu_test.php';</script>";
}

$conn->close();
?>

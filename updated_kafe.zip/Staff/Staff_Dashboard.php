<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff</title>
    <link rel="shortcut icon" type="x-icon" href="Ka'fe logo.png"> <!--KA'fe logo added-->
    <link rel="stylesheet" href="../css/login_tset.css"> <!-- Link to CSS file -->
</head>
<body>
    <header>
        <h1 class="logo">Staff Dashboard</h1>
        <nav class="navigation">
            <a href="Inventory_view.php">Inventory</a>
            <a href="Add to cart.php">Order</a>
            <a href="POS_for_Staff.php">POS</a>
            <a href="#" class="log-out" onclick="confirmLogout()">Log Out</a>
            <style>
                .log-out{
                padding: 10px;
                background-color: #8e6e53; /* Coffee brown */
                color: #f5f0e1; /* Cream text */
                border: none;
                cursor: pointer;
                border-radius: 5px;
                font-size: 18px;
            }
            </style>
            <script>
        function confirmLogout() {
            if (confirm("Are you sure you want to log out?")) {
                window.location.href = '../index.php';
            }
        }
            </script>
        </nav>   
    </header>
</body>
<footer>
    <p>&copy; 2024 Ka'fe. All rights reserved.</p>
</footer>
</html>
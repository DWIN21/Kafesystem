<?php
session_start();

// Database connection
include('../conn/connection.php');

// Handle form submission for completing the order
if (isset($_POST['complete_order'])) {
    // In a real system, you would handle payment processing here

    // After processing the order, clear the cart
    unset($_SESSION['cart']);
    
    // Redirect or display confirmation
    echo "<script>alert('Order Completed! Thank you for your purchase.');</script>";
    echo "<script>window.location.href='menu.php';</script>";
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <link rel="shortcut icon" type="x-icon" href="Ka'fe logo.png">
    <link rel="stylesheet" href="css/login_tset.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #000;
            color: #f8f4f0;
            margin: 0;
            padding: 0;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        header {
            text-align: center;
            padding: 20px;
            background-color: #333;
            color: #fff;
        }
        .back-button {
            background-color: #444;
            color: #f8f4f0;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .back-button:hover {
            background-color: #666;
        }

        h1.logo {
            font-size: 2.5em;
            margin: 0;
            font-family: 'Georgia', serif;
            color: #f8f4f0;
        }

        main {
            flex: 1; /* This ensures the main content takes up the remaining space */
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        table {
            width: 90%;
            margin: 20px auto;
            border-collapse: collapse;
            background-color: #111;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
            border-radius: 10px;
            overflow: hidden;
        }

        th, td {
            padding: 15px;
            text-align: center;
            border-bottom: 1px solid #555;
        }

        th {
            background-color: #444;
            color: #f8f4f0;
            font-weight: bold;
        }

        td {
            background-color: #222;
            color: #f8f4f0;
        }

        .checkout-btn {
            padding: 10px 20px;
            background-color: #f8f4f0;
            color: #333;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-align: center;
        }

        footer {
            text-align: center;
            padding: 20px;
            background-color: #333;
            color: #f8f4f0;
        }

        /* Media Queries for Responsive Design */
        @media screen and (max-width: 768px) {
            h1.logo {
                font-size: 2em;
            }

            table {
                width: 95%;
            }

            th, td {
                padding: 10px;
                font-size: 16px;
            }

            .checkout-btn {
                padding: 8px 16px;
                font-size: 16px;
            }
        }

        @media screen and (max-width: 480px) {
            h1.logo {
                font-size: 1.5em;
            }

            table {
                width: 100%;
            }

            th, td {
                padding: 8px;
                font-size: 14px;
            }

            .checkout-btn {
                padding: 6px 12px;
                font-size: 14px;
            }

            footer p {
                font-size: 12px;
            }
        }
    </style>
</head>

<body>
    <header>
        <h1 class="logo">KA'fe Checkout</h1>
        <button class="back-button" onclick="history.back()">Go Back</button>
    </header>

    <main>
        <table>
            <thead>
                <tr>
                    <th>Item Name</th>
                    <th>Quantity</th>
                    <th>Price</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $total = 0;

                if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
                    foreach ($_SESSION['cart'] as $item_id => $quantity) {
                        $sql = "SELECT * FROM menuitem WHERE MenuItemID = $item_id";
                        $result = $conn->query($sql);
                        $item = $result->fetch_assoc();

                        $item_total = $item['Price'] * $quantity;
                        $total += $item_total;

                        echo "<tr>";
                        echo "<td>{$item['ItemName']}</td>";
                        echo "<td>{$quantity}</td>";
                        echo "<td>{$item['Price']}</td>";
                        echo "<td>{$item_total}</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='4'>Your cart is empty!</td></tr>";
                }
                ?>
            </tbody>
        </table>

        <div style="text-align: center; margin-top: 20px;">
            <h3>Total Amount: ₱<?php echo number_format($total, 2); ?></h3>
            <form method="post" action="payment.php">
    <input type="submit" name="Proceed to Payment" value="Proceed to Payment" class="checkout-btn">
</form>
        </div>
    </main>

    <footer>
        <p>San Jose, Blanga, Bataan.</p>
        <p><u>0956 490 2330</u></p>
        <p><u>kafecoffeehouse@gmail.com</u></p>
        <p>&copy; 2024 Ka'fe. All rights reserved.</p>
    </footer>
</body>

</html>

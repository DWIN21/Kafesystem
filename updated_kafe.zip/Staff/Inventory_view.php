<?php
// Database connection
include('../conn/connection.php');

// Fetch products and their suppliers
$sql = "
SELECT rp.id, rp.name AS product_name, rp.description, rp.cost_per_unit, rp.unit, rp.quantity_in_stock, rp.reorder_level, rp.reorder_quantity, rp.date_added, rp.last_updated, 
s.name AS supplier_name, s.contact_info AS supplier_contact_info
FROM raw_products rp
LEFT JOIN suppliers s ON rp.supplier_id = s.id
ORDER BY rp.name ASC";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory View</title>
    <link rel="shortcut icon" type="image/x-icon" href="../Ka'fe logo.png">
    <style>
        body {
            font-family: 'Georgia', serif;
            margin: 0;
            padding: 0;
            background: url('KAfe background.png') no-repeat center center fixed;
            background-size: cover;
            color: #4b3832;
        }

        .container {
            margin: 20px auto;
            padding: 20px;
            background: rgba(255, 255, 255, 0.9);
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            max-width: 1000px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table th, table td {
            padding: 10px;
            border: 1px solid #d9b38c;
            text-align: left;
        }

        table th {
            background-color: #8e6e53;
            color: #f5f0e1;
        }

        table tr:nth-child(even) {
            background-color: #f5f0e1;
        }

        table tr:hover {
            background-color: #d9b38c;
        }

        .back-button {
            padding: 10px 20px;
            background-color: #8e6e53;
            color: #f5f0e1;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            font-size: 18px;
            text-decoration: none;
            display: inline-block;
        }

        .back-button:hover {
            background-color: #7a5b46;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Inventory</h1>
        <table>
            <thead>
                <tr>
                    <th>Product Name</th>
                    <th>Description</th>
                    <th>Cost Per Unit</th>
                    <th>Unit</th>
                    <th>Quantity in Stock</th>
                    <th>Reorder Level</th>
                    <th>Reorder Quantity</th>
                    <th>Supplier Name</th>
                    <th>Supplier Contact Info</th>
                    <th>Date Added</th>
                    <th>Last Updated</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>
                            <td>{$row['product_name']}</td>
                            <td>{$row['description']}</td>
                            <td>{$row['cost_per_unit']}</td>
                            <td>{$row['unit']}</td>
                            <td>{$row['quantity_in_stock']}</td>
                            <td>{$row['reorder_level']}</td>
                            <td>{$row['reorder_quantity']}</td>
                            <td>{$row['supplier_name']}</td>
                            <td>{$row['supplier_contact_info']}</td>
                            <td>{$row['date_added']}</td>
                            <td>{$row['last_updated']}</td>
                        </tr>";
                    }
                } else {
                    echo "<tr><td colspan='11'>No records found</td></tr>";
                }
                ?>
            </tbody>
        </table>
        <a href="Staff_Dashboard.php" class="back-button">Back</a>
    </div>
</body>
</html>

<?php
$conn->close();
?>

<?php 
    $host="localhost";
    $username="root";
    $password= "Kafecoffeeshop";
    $database= "kafesystem";

    $conn=new mysqli($host,$username,$password,$database);
    if($conn->connect_error){
        echo "Failed to connect database".$conn->connect_error;

    } else{
        echo "connected";
    }
?>
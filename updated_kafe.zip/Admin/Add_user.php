<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add User</title>
    <link rel="shortcut icon" type="image/x-icon" href="../Ka'fe logo.png">
    <link rel="stylesheet" href="login_tset.css"> <!-- Link to CSS file -->
    <style>
    body {
    font-family: 'Georgia', serif;
    margin: 0;
    padding: 0;
    background: url('../background.png') no-repeat center center fixed;
    background-size: cover;
    color: #4b3832;
    display: flex;
    overflow-x: hidden;
}

.sidebar {
    width: 250px;
    height: 100vh;
    background-color: #00bcd4;
    padding: 20px;
    box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
    position: fixed;
    left: 0;
    top: 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    z-index: 1000;
    transition: transform 0.3s ease;
}

.sidebar h1 {
    font-size: 28px;
    font-weight: bold;
    color: rgb(81, 60, 32);
    font-family: 'Times New Roman', cursive;
    margin-bottom: 40px;
    text-align: center;
}

.sidebar nav {
    display: flex;
    flex-direction: column;
    width: 100%;
}

.sidebar a {
    color: #fff;
    text-decoration: none;
    margin: 10px 0;
    font-size: 18px;
    padding: 10px;
    text-align: center;
    display: block;
    border-radius: 5px;
    transition: background-color 0.3s, color 0.3s;
}

.sidebar a:hover {
    color: #ffeb3b;
    background-color: #00796b;
}

.main-content {
    margin-left: 250px;
    padding: 20px;
    flex: 1;
    transition: margin-left 0.3s ease;
}

.toggle-btn {
    position: fixed;
    top: 20px;
    left: 20px;
    background-color: #00bcd4;
    color: #fff;
    border: none;
    padding: 10px 20px;
    font-size: 16px;
    cursor: pointer;
    border-radius: 5px;
    z-index: 1001;
    transition: background-color 0.3s;
}

.toggle-btn:hover {
    background-color: #00796b;
}

.sidebar.hidden {
    transform: translateX(-100%);
}

.main-content.sidebar-hidden {
    margin-left: 0;
}

.dropdown {
    position: relative;
    display: inline-block;
    margin-bottom: 20px;
    margin-left: 55px;
}

.dropdown-button {
    background-color: black;
    color: white;
    border: none;
    padding: 10px 20px;
    
    font-size: 16px;
    cursor: pointer;
    border-radius: 5px;
    transition: background-color 0.3s;
}

.dropdown-button:hover {
    background-color: white;
    color: black;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
    border-radius: 5px;
    margin-top: 10px;
}

.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.dropdown-content a:hover {
    background-color: #f1f1f1;
}

.dropdown:hover .dropdown-content {
    display: block;
}

form {
    background-color: white;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    max-width: 400px;
    margin: 20px auto;
}

form label {
    display: block;
    margin-bottom: 8px;
    font-weight: bold;
}

form input,
form select {
    width: 100%;
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 5px;
    margin-bottom: 15px;
    box-sizing: border-box;
}

form input[type="submit"] {
    background-color: #333;
    color: white;
    border: none;
    cursor: pointer;
    padding: 10px;
    border-radius: 5px;
}

form input[type="submit"]:hover {
    background-color: #555;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin: 20px 0;
    background-color: white;
    border: 1px solid #ddd;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

table, th, td {
    border: 1px solid #ddd;
}

th, td {
    padding: 8px;
    text-align: left;
}

th {
    background-color: #f2f2f2;
}

td {
    background-color: #fff;
}

footer {
    background-color: rgba(255, 255, 255, 0.8);
    text-align: center;
    padding: 10px 0;
    width: 100%;
    bottom: 0;
    box-shadow: 0 -4px 6px rgba(0, 0, 0, 0.1);
    position: fixed;
}

footer p {
    margin: 0;
    color: rgb(81, 60, 32);
}

@media (max-width: 768px) {
    .sidebar {
        width: 200px;
    }

    .sidebar h1 {
        font-size: 24px;
    }

    .sidebar a {
        font-size: 16px;
    }

    .main-content {
        margin-left: 200px;
    }

    .dropdown-button {
        font-size: 14px;
        padding: 8px 16px;
    }

    .dropdown-content a {
        font-size: 14px;
        padding: 10px 12px;
    }
}

@media (max-width: 600px) {
    .sidebar {
        width: 100%;
        height: auto;
        position: relative;
        box-shadow: none;
    }

    .sidebar h1 {
        font-size: 20px;
        margin-bottom: 20px;
    }

    .sidebar a {
        font-size: 14px;
    }

    .main-content {
        margin-left: 0;
    }

    .dropdown-button {
        font-size: 14px;
        padding: 8px 16px;
    }

    .dropdown-content a {
        font-size: 14px;
        padding: 10px 12px;
    }
}

    </style>
</head>
<body>
    <button class="toggle-btn" id="toggleBtn">≡</button>
    <div class="sidebar" id="sidebar">
        <h1>ACCOUNT MANAGEMENT</h1>
        <nav>
            <a href="Admin_Dashboard.php">Admin Dashboard</a>
            <a href="Menu_test.php">Menu</a>
            <a href="Inventory_test.php">Inventory</a>
            <a href="POS_test.php">POS</a>
            <a href="Report_test.html">Report</a>
            <a href="Add_user.php">Add User</a>
        </nav>
    </div>
    <div class="main-content" id="mainContent">
        <!-- Dropdown Menu -->
        <div class="dropdown">
            <button class="dropdown-button">Manage Users</button>
            <div class="dropdown-content">
                <a href="#" id="addUserLink">Add User</a>
                <a href="#" id="viewUsersLink">View Users</a>
            </div>
        </div>
        <div id="addUserForm">
            <form action="add_user.php" method="post">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required><br>
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required><br>
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required><br>
                <label for="confirm_password">Confirm Password:</label>
                <input type="password" id="confirm_password" name="confirm_password" required><br>
                <label for="role">Role:</label>
                <select id="role" name="role" required>
                    <option value="admin">Admin</option>
                    <option value="staff">Staff</option>
                </select><br><br>
                <input type="submit" value="Add User">
            </form>
<?php
include('../conn/connection.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['username']) && isset($_POST['email']) && isset($_POST['password']) && isset($_POST['confirm_password']) && isset($_POST['role'])) {
        // Retrieve form data
        $user = $_POST['username'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $confirm_password = $_POST['confirm_password'];
        $role = $_POST['role'];

        // Validate passwords
        if ($password !== $confirm_password) {
            echo "<script>alert('Passwords do not match.'); window.location.href='Add_user.php';</script>";
            exit();
        }

        $stmt = $conn->prepare("INSERT INTO users (username, Email, password, role) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $user, $email, $password, $role);

        // Execute the statement
        if ($stmt->execute()) {
            echo "<script>alert('New user added successfully.'); window.location.href='Add_user.php';</script>";
        } else {
            echo "Error: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Error: Missing required fields.";
    }
} else {
    echo "Error: Form not submitted.";
}

// Close the connection
$conn->close();
?>
</div>
        <div id="viewUsersForm" style="display:none;">
    <?php
    include('../conn/connection.php');
    // Fetch users from the database
    $sql = "SELECT username, email, role FROM users";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Display data in a table
        echo "<table>
                <thead>
                    <tr>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Role</th>
                    </tr>
                </thead>
                <tbody>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>" . htmlspecialchars($row["username"]) . "</td>
                    <td>" . htmlspecialchars($row["email"]) . "</td>
                    <td>" . htmlspecialchars($row["role"]) . "</td>
                  </tr>";
        }
        echo "</tbody></table>";
    } else {
        echo "<p>No users found.</p>";
    }

    // Close the connection
    $conn->close();
    ?>
</div>
        
        </div>
    </div>
    <footer>
        <p>&copy; 2024 Ka'fe. All rights reserved</p>
    </footer>
    <script>
        document.getElementById('toggleBtn').addEventListener('click', function() {
            var sidebar = document.getElementById('sidebar');
            var mainContent = document.getElementById('mainContent');

            if (sidebar.classList.contains('hidden')) {
                sidebar.classList.remove('hidden');
                mainContent.classList.remove('sidebar-hidden');
            } else {
                sidebar.classList.add('hidden');
                mainContent.classList.add('sidebar-hidden');
            }
        });

        document.getElementById('addUserLink').addEventListener('click', function() {
            document.getElementById('addUserForm').style.display = 'block';
            document.getElementById('viewUsersForm').style.display = 'none';
        });

        document.getElementById('viewUsersLink').addEventListener('click', function() {
            document.getElementById('viewUsersForm').style.display = 'block';
            document.getElementById('addUserForm').style.display = 'none';
        });
    </script>
</body>
</html>

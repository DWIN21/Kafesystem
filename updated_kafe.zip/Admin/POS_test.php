<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Point of Sale</title>
    <link rel="shortcut icon" type="image/x-icon" href="Ka'fe logo.png">
    <link rel="stylesheet" href="../css/POS.css">
</head>
<body>
    <header>
        <h1 class="logo">P-O-S</h1>
    </header>
    <div class="sidebar">
        <h2>Menu</h2>
        <nav>
            <a href="Admin_Dashboard.php">Admin Dashboard</a>
            <a href="Menu_test.php">Menu</a>
            <a href="Inventory_test.php">Inventory</a>
            <a href="POS_test.php">POS</a>
            <a href="Report_test.html">Report</a>
            <a href="Add_user.php">Add User</a>
        </nav>
    </div>
    <main class="content">
        <div class="pos-container">
            <h2>Order</h2>
            <form class="pos-form" id="pos-form">
                <label for="category-select">Category</label>
                <select id="category-select">
                    <!-- Categories will be populated here -->
                </select>
                <label for="product-select">Product</label>
                <select id="product-select">
                    <!-- Products will be populated here -->
                </select>
                <label for="product-quantity">Quantity</label>
                <input type="number" id="product-quantity" placeholder="Quantity" required>
                <button type="button" id="add-to-cart">Add to Cart</button>
            </form>
        </div>
        <div class="receipt-section" id="receipt-section">
            <h3>Receipt</h3>
            <ul id="receipt-list">
                <!-- Items will be added here dynamically -->
            </ul>
        </div>
        <div class="discount-section">
            <h3>Discount</h3>
            <form class="discount-form" id="discount-form">
                <label for="discount-type">Discount Type</label>
                <select id="discount-type">
                    <option value="percentage">Percentage</option>
                    <option value="fixed">Fixed Amount</option>
                </select>
                <label for="discount-value">Discount Value</label>
                <input type="number" id="discount-value" placeholder="Discount Value" required>
                <button type="button" id="apply-discount">Apply Discount</button>
            </form>
        </div>
        <div class="payment-section">
            <h3>Payment</h3>
            <form class="payment-form" id="payment-form">
                <label for="payment-method">Payment Method</label>
                <select id="payment-method">
                    <option value="cash">Cash</option>
                    <option value="Gcash">Gcash</option>
                </select>
                <label for="amount-tendered">Amount Tendered</label>
                <input type="number" id="amount-tendered" placeholder="Amount Tendered" required>
                <button type="button" id="process-payment">Process Payment</button>
                <button type="button" class="Confirm">Confirm</button>
            </form>
        </div>
    </main>
    <footer>
        <p>© 2024 Coffee Shop POS System</p>
    </footer>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const categorySelect = document.getElementById('category-select');
            const productSelect = document.getElementById('product-select');
            const receiptList = document.getElementById('receipt-list');

            // Fetch categories from the server
            fetch('../php function/get_categories.php')
                .then(response => response.json())
                .then(data => {
                    populateCategories(data.categories);
                })
                .catch(error => console.error('Error fetching categories:', error));

            // Populate categories dropdown
            function populateCategories(categories) {
                categorySelect.innerHTML = '<option value="">Select a category</option>';
                categories.forEach(category => {
                    const option = document.createElement('option');
                    option.value = category.Category;
                    option.textContent = category.Category;
                    categorySelect.appendChild(option);
                });

                // Populate products based on the first category
                if (categories.length > 0) {
                    populateProducts(categories[0].Category);
                }
            }

            // Populate products dropdown based on selected category
            function populateProducts(category) {
                fetch(`../php function/get_products.php?category=${encodeURIComponent(category)}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.error) {
                            console.error('Error:', data.error);
                            productSelect.innerHTML = '<option value="">Error fetching products</option>';
                            return;
                        }

                        productSelect.innerHTML = '<option value="">Select a product</option>';
                        data.products.forEach(product => {
                            const option = document.createElement('option');
                            option.value = product.ItemID;
                            option.textContent = `${product.ItemName} - ₱${product.Price}`;
                            option.dataset.price = product.Price; // Store price in data attribute
                            productSelect.appendChild(option);
                        });
                    })
                    .catch(error => console.error('Error fetching products:', error));
            }

            // Handle category selection change
            categorySelect.addEventListener('change', function() {
                const selectedCategory = this.value;
                if (selectedCategory) {
                    populateProducts(selectedCategory);
                } else {
                    productSelect.innerHTML = '<option value="">Select a product</option>';
                }
            });

            // Handle adding product to the cart
            document.getElementById('add-to-cart').addEventListener('click', function() {
                const selectedProduct = productSelect.options[productSelect.selectedIndex];
                const productName = selectedProduct.text;
                const productQuantity = document.getElementById('product-quantity').value;
                const productPrice = selectedProduct.dataset.price; // Get price from data attribute

                if (productQuantity > 0) {
                    addProductToReceipt(productName, productQuantity, productPrice);
                }
            });

            // Add product to receipt list
            function addProductToReceipt(name, quantity, price) {
                const listItem = document.createElement('li');
                const totalPrice = (price * quantity).toFixed(2);
                listItem.innerHTML = `<span>${name} x ${quantity} - ₱${totalPrice}</span><button class="remove-item">Remove</button>`;
                receiptList.appendChild(listItem);

                // Handle removing item from receipt
                listItem.querySelector('.remove-item').addEventListener('click', function() {
                    receiptList.removeChild(listItem);
                });
            }
        });
    </script>
</body>
</html>

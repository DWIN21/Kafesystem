<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Management</title>
    <link rel="shortcut icon" type="image/x-icon" href="Ka'fe logo.png">
    <style>
        body {
            font-family: 'Georgia', serif;
            margin: 0;
            padding: 0;
            background: url('KAfe background.png') no-repeat center center fixed;
            background-size: cover;
            color: #4b3832;
            transition: margin-left 0.3s;
        }

        .sidebar {
            width: 250px;
            height: 100vh;
            background-color: #00bcd4;
            padding: 20px;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
            position: fixed;
            left: 0;
            top: 0;
            transition: transform 0.3s ease;
            transform: translateX(0);
            z-index: 1000;
        }

        .sidebar.hide {
            transform: translateX(-100%);
        }

        .sidebar h1 {
            font-size: 28px;
            font-weight: bold;
            color: rgb(81, 60, 32);
            margin-bottom: 40px;
            text-align: center;
        }

        .sidebar nav {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 0;
        }

        .sidebar a {
            color: white;
            text-decoration: none;
            margin: 15px 0;
            font-size: 18px;
            transition: color 0.3s;
            text-align: center;
            display: block;
            width: 100%;
        }

        .sidebar a:hover {
            color: yellow;
            background-color: #00796b;
        }

        .sidebar-toggle {
            position: fixed;
            top: 15px;
            left: 15px;
            background-color: cyan;
            border: none;
            border-radius: 5px;
            padding: 10px;
            cursor: pointer;
            z-index: 1100;
        }

        .sidebar-toggle .bar {
            display: block;
            width: 20px;
            height: 2px;
            background-color: #fff;
            margin: 4px 0;
        }

        main {
            margin-left: 250px;
            padding: 20px;
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            height: 100vh;
            transition: margin-left 0.3s;
        }

        main.shifted {
            margin-left: 0;
        }

        .form-container {
            background: rgba(255, 255, 255, 0.9);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 500px;
        }

        .form-container label {
            display: block;
            margin: 10px 0 5px;
            font-weight: bold;
        }

        .form-container input {
            padding: 10px;
            margin: 5px 0 15px;
            border: 1px solid #d9b38c;
            border-radius: 5px;
            font-size: 16px;
            width: 100%;
            box-sizing: border-box;
        }

        .form-container button {
            padding: 10px 20px;
            background-color: #8e6e53;
            color: #f5f0e1;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            font-size: 18px;
            margin: 10px 0;
            width: 100%;
            transition: background-color 0.3s;
        }

        .form-container button:hover {
            background-color: #7a5b46;
        }

        .inventory-section {
            width: 100%;
            max-width: 800px;
            background: rgba(255, 255, 255, 0.9);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            margin-top: 30px;
        }

        .inventory-section h2 {
            background-color: #d9b38c;
            padding: 10px;
            border-radius: 5px;
            color: #4b3832;
            text-align: center;
            margin-bottom: 20px;
        }

        .inventory-section ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }

        .inventory-section li {
            background-color: #f5f0e1;
            margin: 10px 0;
            padding: 10px 20px;
            border-radius: 5px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: transform 0.3s;
        }

        .inventory-section li:hover {
            transform: scale(1.02);
        }

        .inventory-section li button {
            background-color: #8e6e53;
            color: #f5f0e1;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            padding: 5px 10px;
            margin-left: 10px;
            transition: background-color 0.3s;
        }

        .inventory-section li button:hover {
            background-color: #7a5b46;
        }

        footer {
            background-color: rgba(255, 255, 255, 0.8);
            text-align: center;
            padding: 10px 0;
            position: fixed;
            width: 100%;
            bottom: 0;
            box-shadow: 0 -4px 6px rgba(0, 0, 0, 0.1);
        }

        footer p {
            margin: 0;
            color: rgb(81, 60, 32);
        }

        .toggle-content {
            display: none;
            margin-top: 10px;
            padding: 10px;
            background-color: #f9f9f9;
            border: 1px solid #d9b38c;
            border-radius: 5px;
        }

        .toggle-content.show {
            display: block;
        }

        .toggle-button {
            background-color: #00bcd4;
            color: #fff;
            border: none;
            padding: 10px;
            cursor: pointer;
            border-radius: 5px;
            font-size: 16px;
            margin: 10px 0;
            display: block;
            width: 100%;
            text-align: center;
        }

        .toggle-button:hover {
            background-color: #0097a7;
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 200px;
            }

            .sidebar h1 {
                font-size: 24px;
            }

            .sidebar a {
                font-size: 16px;
            }

            main {
                margin-left: 0;
            }
        }

        @media (min-width: 769px) {
            main.shifted {
                margin-left: 250px;
            }
        }
    </style>
</head>
<body>
    <button class="sidebar-toggle">
        <div class="bar"></div>
        <div class="bar"></div>
        <div class="bar"></div>
    </button>
    <div class="sidebar">
        <h1>INVENTORY MANAGEMENT</h1>
        <nav>
            <a href="Admin_Dashboard.php">Admin Dashboard</a>
            <a href="Menu_test.php">Menu</a>
            <a href="Inventory_test.php">Inventory</a>
            <a href="POS_test.php">POS</a>
            <a href="Report_test.html">Report</a>
            <a href="Add_user.php">Add User</a>
        </nav>   
    </div>
    <main>
        <div>
            <form action="Inventory_test.php" method="post">
                <div class="form-container">
                    <h2>Add Product</h2>
                    <label for="product-name">Product Name</label>
                    <input type="text" id="product-name" name="product_name" placeholder="Product Name" required>
                    <label for="product-description">Description</label>
                    <input type="text" id="product-description" name="product_description" placeholder="Description" required>
                    <label for="product-cost">Cost Per Unit</label>
                    <input type="number" step="0.01" id="product-cost" name="product_cost" placeholder="Cost Per Unit" required>
                    <label for="product-quantity">Quantity</label>
                    <input type="number" id="product-quantity" name="product_quantity" placeholder="Quantity" required>
                    <label for="product-unit">Unit</label>
                    <input type="text" id="product-unit" name="product_unit" placeholder="Unit (e.g., kg, L, pcs)" required>
                    <label for="reorder-level">Reorder Level</label>
                    <input type="number" id="reorder-level" name="reorder_level" placeholder="Reorder Level" required>
                    <label for="reorder-quantity">Reorder Quantity</label>
                    <input type="number" id="reorder-quantity" name="reorder_quantity" placeholder="Reorder Quantity" required>
                    <label for="supplier-name">Supplier Name</label>
                    <input type="text" id="supplier-name" name="supplier_name" placeholder="Supplier Name">
                    <label for="supplier-contact-info">Supplier Contact Info</label>
                    <input type="text" id="supplier-contact-info" name="supplier_contact_info" placeholder="Supplier Contact Info">
                    <button type="submit">Add Product</button>
                </div>
            </form>
        </div>
    </main>
    <footer>
        <p>&copy; 2024 Ka'fe. All rights reserved.</p>
    </footer>
    <script>
        document.querySelector('.sidebar-toggle').addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('hide');
            document.querySelector('main').classList.toggle('shifted');
        });
    </script>
</body>
</html>

<?php
// Database connection
include('../conn/connection.php');
// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve and sanitize form data
    $product_name = $conn->real_escape_string($_POST['product_name'] ?? '');
    $product_description = $conn->real_escape_string($_POST['product_description'] ?? '');
    $product_cost = (float)($_POST['product_cost'] ?? 0);
    $product_quantity = (int)($_POST['product_quantity'] ?? 0);
    $product_unit = $conn->real_escape_string($_POST['product_unit'] ?? '');
    $reorder_level = (int)($_POST['reorder_level'] ?? 0);
    $reorder_quantity = (int)($_POST['reorder_quantity'] ?? 0);
    $supplier_name = $conn->real_escape_string($_POST['supplier_name'] ?? '');
    $supplier_contact_info = $conn->real_escape_string($_POST['supplier_contact_info'] ?? '');

    // Check if required fields are not empty
    if (empty($product_name) || $product_cost <= 0 || $product_quantity <= 0 || empty($product_unit)) {
        die("Error: Please fill in all required fields.");
    }

    // Check if supplier already exists
    $supplier_id = null;
    if (!empty($supplier_name) && !empty($supplier_contact_info)) {
        $checkSupplierSql = "SELECT id FROM suppliers WHERE name = ? AND contact_info = ?";
        $checkStmt = $conn->prepare($checkSupplierSql);
        if ($checkStmt === false) {
            die("Prepare failed: " . $conn->error);
        }
        $checkStmt->bind_param("ss", $supplier_name, $supplier_contact_info);
        $checkStmt->execute();
        $checkStmt->bind_result($supplier_id);
        $checkStmt->fetch();
        $checkStmt->close();

        if (empty($supplier_id)) {
            // Insert new supplier
            $insertSupplierSql = "INSERT INTO suppliers (name, contact_info) VALUES (?, ?)";
            $insertStmt = $conn->prepare($insertSupplierSql);
            if ($insertStmt === false) {
                die("Prepare failed: " . $conn->error);
            }
            $insertStmt->bind_param("ss", $supplier_name, $supplier_contact_info);
            if ($insertStmt->execute()) {
                $supplier_id = $insertStmt->insert_id;
            } else {
                die("Error: " . $insertStmt->error);
            }
            $insertStmt->close();
        }
    }

    // Insert product
    $sql = "INSERT INTO raw_products (name, description, supplier_id, cost_per_unit, unit, quantity_in_stock, reorder_level, reorder_quantity, date_added, last_updated)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())";

    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("ssddsiii", $product_name, $product_description, $supplier_id, $product_cost, $product_unit, $product_quantity, $reorder_level, $reorder_quantity);

    if ($stmt->execute()) {
        // Redirect or notify the user
        echo "<script>alert('New record created successfully!'); window.location.href='inventory_view.php';</script>";
        exit;
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>

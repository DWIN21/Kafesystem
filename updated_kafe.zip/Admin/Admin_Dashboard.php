<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="shortcut icon" type="x-icon" href="../Ka'fe logo.png"> <!--KA'fe logo added-->
    <link rel="stylesheet" href="../css/login_tset.css"> <!-- Link to CSS file -->
    <style>
        .log-out {
            padding: 10px;
            background-color: #8e6e53; /* Coffee brown */
            color: #f5f0e1; /* Cream text */
            border: none;
            cursor: pointer;
            border-radius: 5px;
            font-size: 18px;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <header>
        <h1 class="logo">Admin Dashboard</h1>
        <nav class="navigation">
            <a href="Admin_Dashboard.php">Admin Dashboard</a>
            <a href="Menu_test.php">Menu</a>
            <a href="Inventory_test.php">Inventory</a>
            <a href="POS_test.php">POS</a>
            <a href="Report_test.html">Report</a>
            <a href="Add_user.php">Add User</a>
            <a href="#" class="log-out" onclick="confirmLogout()">Log Out</a>
        </nav>
    </header>
    <script>
        function confirmLogout() {
            if (confirm("Are you sure you want to log out?")) {
                window.location.href = '../index.php';
            } 
        }
    </script>

</body>
<footer>
    <p>&copy; 2024 Ka'fe. All rights reserved.</p>
</footer>
</html>

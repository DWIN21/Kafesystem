<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu Management</title>
    <link rel="shortcut icon" type="image/x-icon" href="Ka'fe logo.png">
    <style>
        body {
            font-family: 'Georgia', serif;
            margin: 0;
            padding: 0;
            background: url('../ background.png') no-repeat center center fixed;
            background-size: cover;
            color: #4b3832;
            display: flex;
            transition: margin-left 0.3s;
        }

        .sidebar {
            width: 250px;
            height: 100vh;
            background-color: #00bcd4;
            padding: 20px;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
            position: fixed;
            left: 0;
            top: 0;
            transition: transform 0.3s ease;
            transform: translateX(0);
            z-index: 1000;
        }

        .sidebar.hide {
            transform: translateX(-100%);
        }

        .sidebar h1 {
            font-size: 28px;
            font-weight: bold;
            color: rgb(81, 60, 32);
            margin-bottom: 40px;
            text-align: center;
        }

        .sidebar nav {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 0;
        }

        .sidebar a {
            color: #fff;
            text-decoration: none;
            margin: 15px 0;
            font-size: 18px;
            transition: color 0.3s;
            text-align: center;
            display: block;
            width: 100%;
        }

        .sidebar a:hover {
            color: #ffeb3b;
        }

        .sidebar-toggle {
            position: fixed;
            top: 15px;
            left: 15px;
            background-color: #00bcd4;
            border: none;
            border-radius: 5px;
            padding: 10px;
            cursor: pointer;
            z-index: 1100;
        }

        .sidebar-toggle .bar {
            display: block;
            width: 20px;
            height: 2px;
            background-color: #fff;
            margin: 4px 0;
        }

        main {
            margin-left: 250px;
            padding: 20px;
            flex: 1;
            transition: margin-left 0.3s;
        }

        main.shifted {
            margin-left: 0;
        }

        .form-container {
            background: rgba(255, 255, 255, 0.9);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 600px;
            box-sizing: border-box;
            margin: 20px auto;
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .form-container label {
            display: block;
            margin: 0 0 5px;
            font-weight: bold;
        }

        .form-container select,
        .form-container input,
        .form-container textarea {
            padding: 12px;
            border: 1px solid #d9b38c;
            border-radius: 5px;
            font-size: 16px;
            width: 100%;
            box-sizing: border-box;
        }

        .form-container button {
            padding: 12px;
            background-color: #8e6e53;
            color: #fff;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            font-size: 16px;
            transition: background-color 0.3s;
            width: 100%;
            box-sizing: border-box;
        }

        #add-ingredient-btn {
            padding: 8px;
            margin-bottom: 5px;
            font-size: 14px;
            width: auto;
            align-self: flex-start;
        }

        .form-container button[type="submit"] {
            padding: 16px;
            font-size: 18px;
        }

        .ingredient-section {
            margin-top: 20px;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .ingredient-input {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 10px;
        }

        .ingredient-input label {
            flex: 1;
        }

        .ingredient-input input {
            flex: 2;
        }

        .inventory-section {
            width: 100%;
            max-width: 800px;
            background: rgba(255, 255, 255, 0.9);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            margin: 20px auto;
        }

        .inventory-section h2 {
            background-color: #d9b38c;
            padding: 10px;
            border-radius: 5px;
            color: #4b3832;
            text-align: center;
            margin-bottom: 20px;
        }

        .inventory-section ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }

        .inventory-section li {
            background-color: #f5f0e1;
            margin: 10px 0;
            padding: 10px 20px;
            border-radius: 5px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: transform 0.3s;
        }

        .inventory-section li:hover {
            transform: scale(1.02);
        }

        .inventory-section li button {
            background-color: #8e6e53;
            color: #f5f0e1;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            padding: 5px 10px;
            margin-left: 10px;
            transition: background-color 0.3s;
        }

        .inventory-section li button:hover {
            background-color: #7a5b46;
        }

        footer {
            background-color: rgba(255, 255, 255, 0.8);
            text-align: center;
            padding: 10px 0;
            width: 100%;
            bottom: 0;
            box-shadow: 0 -4px 6px rgba(0, 0, 0, 0.1);
            position: fixed;
        }

        footer p {
            margin: 0;
            color: rgb(81, 60, 32);
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 200px;
            }

            .sidebar h1 {
                font-size: 24px;
            }

            .sidebar a {
                font-size: 16px;
            }

            main {
                margin-left: 0;
            }

            .form-container {
                padding: 15px;
                gap: 10px;
            }

            .form-container button {
                font-size: 14px;
                padding: 10px;
            }
        }

        @media (min-width: 769px) {
            main.shifted {
                margin-left: 250px;
            }
        }
        .ingredient-input {
        display: grid;
        grid-template-columns: 1fr 2fr 1fr 1fr;
        gap: 10px;
        align-items: center;
        margin-bottom: 10px;
    }

    .ingredient-input label {
        margin: 0;
        font-weight: bold;
    }

    .ingredient-input input,
    .ingredient-input select {
        padding: 10px;
        border: 1px solid #d9b38c;
        border-radius: 5px;
        font-size: 16px;
        box-sizing: border-box;
        width: 100%;
    }
    </style>
</head>
<body>
    <button class="sidebar-toggle">
        <div class="bar"></div>
        <div class="bar"></div>
        <div class="bar"></div>
    </button>
    <div class="sidebar">
        <h1>MENU MANAGEMENT</h1>
        <nav>
            <a href="Admin_Dashboard.php">Admin Dashboard</a>
            <a href="Menu_test.php">Menu</a>
            <a href="Inventory_test.php">Inventory</a>
            <a href="POS_test.php">POS</a>
            <a href="Report_test.html">Report</a>
            <a href="Add_user.php">Add User</a>
        </nav>
    </div>
    <main>
        <div class="form-container">
            <h2>Add Menu Item</h2>
            <form action="Menu_test.php" method="POST" enctype="multipart/form-data">
                <label for="category">Category</label>
                <select id="category" name="category" required>
                    <option value="drinks">Drinks</option>
                    <option value="Cakes">Cakes</option>
                    <option value="Coffee">Coffee</option>
                    <option value="Fraffe">Fraffe</option>
                    <option value="Fruits">Fruit Drinks</option>
                </select>
                <label for="menu-name">Menu Name</label>
                <input type="text" id="menu-name" name="menu-name" placeholder="Menu Name" required>
                <label for="product-price">Product Price</label>
                <input type="number" id="product-price" name="product-price" placeholder="Product Price" required>
                <label for="description">Description</label>
                <textarea id="description" name="description" placeholder="Description" rows="4" required></textarea>
                <label for="menu_image">Upload Image:</label>
                <input type="file" id="menu_image" name="menu_image">

                <div class="ingredient-section">
                    <h3>Ingredients</h3>
                    <div id="ingredients-container">
                        <!-- Ingredient inputs will be added here -->
                    </div>
                    <button id="add-ingredient-btn">Add Ingredient</button>
                </div>

                <button type="submit">Add Menu Item</button>
            </form>
        </div>
    </main>
    <footer>
        <p>&copy; 2024 Ka'fe. All rights reserved.</p>
    </footer>
    <script>
        let ingredientCount = 0;
        const maxIngredients = 10;

        document.getElementById('add-ingredient-btn').addEventListener('click', function(event) {
            event.preventDefault();
            if (ingredientCount < maxIngredients) {
                ingredientCount++;
                const ingredientsContainer = document.getElementById('ingredients-container');
                const ingredientDiv = document.createElement('div');
                ingredientDiv.classList.add('ingredient-input');
                ingredientDiv.innerHTML = `
                    <label for="ingredient-${ingredientCount}">Ingredient ${ingredientCount}</label>
                    <select id="ingredient-${ingredientCount}" name="ingredient-${ingredientCount}" required>
                        <!-- Options will be populated by PHP -->
                    </select>
                    <label for="quantity-${ingredientCount}">Quantity</label>
                    <input type="text" id="quantity-${ingredientCount}" name="quantity-${ingredientCount}" placeholder="Quantity" required>
                    <label for="unit-${ingredientCount}">Unit</label>
                    <select id="unit-${ingredientCount}" name="unit-${ingredientCount}" required>
                        <option value="g">Grams</option>
                        <option value="ml">Milliliters</option>
                        <option value="pcs">Pieces</option>
                    </select>
                `;
                ingredientsContainer.appendChild(ingredientDiv);

                // Populate ingredient options
                fetch('../php function/get_ingredients.php')
                    .then(response => response.text())
                    .then(data => {
                        document.querySelector(`#ingredient-${ingredientCount}`).innerHTML = data;
                    });
            }
        });

        document.querySelector('.sidebar-toggle').addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('hide');
            document.querySelector('main').classList.toggle('shifted');
        });
    </script>
</body>
</html>
<?php
include('../conn/connection.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $itemName = $_POST['menu-name'] ?? '';
    $description = $_POST['description'] ?? '';
    $price = $_POST['product-price'] ?? 0;
    $category = $_POST['category'] ?? '';
    $imageName = '';

    // Handle file upload
    if (isset($_FILES['menu_image']) && $_FILES['menu_image']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['menu_image']['tmp_name'];
        $fileName = $_FILES['menu_image']['name'];
        $fileSize = $_FILES['menu_image']['size'];
        $fileType = $_FILES['menu_image']['type'];
        $fileNameCmps = explode(".", $fileName);
        $fileExtension = strtolower(end($fileNameCmps));
        $allowedfileExtensions = array('jpg', 'gif', 'png', 'jpeg');

        if (in_array($fileExtension, $allowedfileExtensions)) {
            $uploadFileDir = 'uploads/';
            if (!is_dir($uploadFileDir)) {
                mkdir($uploadFileDir, 0777, true);
            }
            $newFileName = md5(time() . $fileName) . '.' . $fileExtension;
            $dest_path = $uploadFileDir . $newFileName;

            if (move_uploaded_file($fileTmpPath, $dest_path)) {
                $imageName = $newFileName;
            } else {
                echo "Error moving the uploaded file.";
                exit;
            }
        } else {
            echo "Upload failed. Allowed file types: " . implode(', ', $allowedfileExtensions);
            exit;
        }
    }

    // Insert menu item
    $sql = "INSERT INTO MenuItem (ItemName, Description, Price, Category, ImageName) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Prepare failed: " . $conn->error);
    }
    $stmt->bind_param("ssdss", $itemName, $description, $price, $category, $imageName);
    $stmt->execute();
    $menuItemID = $stmt->insert_id; // Get the last inserted ID

    // Insert ingredients
    for ($i = 1; $i <= 10; $i++) {
        if (isset($_POST["ingredient-$i"]) && isset($_POST["quantity-$i"]) && isset($_POST["unit-$i"])) {
            $rawProductID = $_POST["ingredient-$i"];
            $quantity = $_POST["quantity-$i"];
            $unit = $_POST["unit-$i"];

            // Insert into ingredient_raw_product
            $sql = "INSERT INTO ingredient_raw_product (menu_item_id, raw_product_id, quantity, unit) VALUES (?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            if ($stmt === false) {
                die("Prepare failed: " . $conn->error);
            }
            $stmt->bind_param("iiss", $menuItemID, $rawProductID, $quantity, $unit);
            $stmt->execute();
        }
    }

    echo "<script>alert('Menu item added successfully!'); window.location.href='Menu_test.php';</script>";
}

$conn->close();
?>

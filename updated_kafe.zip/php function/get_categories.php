<?php
include('../conn/connection.php');
// Fetch categories
$sql = "SELECT DISTINCT Category FROM MenuItem";
$result = $conn->query($sql);

$categories = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $categories[] = $row;
    }
}

$conn->close();

header('Content-Type: application/json');
echo json_encode(['categories' => $categories]);
?>

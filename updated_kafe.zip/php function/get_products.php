<?php
// Database configuration
$servername = "localhost";
$username = "root"; // Update with your database username
$password = ""; // Update with your database password
$dbname = "kafesystem"; // Update with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$category = $_GET['category'] ?? '';

$products = [];

if ($category) {
    $stmt = $conn->prepare("SELECT MenuItemID, ItemName, Price FROM menuitem WHERE Category = ?");
    $stmt->bind_param('s', $category);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $products[] = $row;
    }

    $stmt->close();
}

$conn->close();

header('Content-Type: application/json');
echo json_encode(['products' => $products]);
?>